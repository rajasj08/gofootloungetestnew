1.1
===

 - Added mixin for controlling font-feature-settings available in the font.
 - Updated and rearranged demo files.

1.0
===

Initial release.
