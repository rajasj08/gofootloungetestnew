Raleway Webfont
===============

All 9 weights of the font as retrieved on 2014-08-18 from [Font Squirrel](http://www.fontsquirrel.com/fonts/Raleway), converted using their Webfont Generator with the settings in [generator_config.txt](generator_config.txt).

The demo is best viewed from a web server, e.g., from the **main directory of the repository**:

    $ python -m SimpleHTTPServer 1234

and then navigate to http://localhost:1234/demo.
